# GitHub de Diblaim — Atualização visual V2

Esta atualização **não apaga os arquivos antigos em `assets/`**. Ela mantém as mesmas seções (banner, texto animado, contadores, sobre mim, tech stack, ferramentas, quatro projetos, terminal de objetivos, estatísticas, streak, atividade, troféus, cobrinha, contato e rodapé).

## Arquivos

- `README.md`: versão V2 do README do perfil.
- `assets-v2/`: novo banner, divisor, terminal de objetivos e rodapé, todos em SVG.
- `.github/workflows/snake.yml`: gera diariamente `github-snake.svg` e `github-snake-dark.svg` e publica na branch `output`.

## Como publicar com segurança

1. Acesse `https://github.com/imlean64-gif/imlean64-gif` e **faça backup do seu README atual**.
2. No computador, extraia este ZIP e copie os arquivos para uma pasta local clonada desse repositório, mantendo a estrutura de pastas. Seu `assets/` antigo deve continuar no lugar.
3. Envie o commit para a branch `main`. Confira se `assets-v2/` contém quatro SVGs e se `.github/workflows/snake.yml` foi enviado.
4. Abra a aba **Actions** no seu repositório e execute manualmente o workflow **Atualizar cobrinha de contribuicoes** em `Run workflow`. Isso cria a branch `output` da cobrinha. A atualização diária fica agendada.
5. Se Actions não conseguir gravar na branch `output`, confira em **Settings → Actions → General → Workflow permissions** se a configuração permite escrita via GITHUB_TOKEN.
6. Aguarde a atualização dos cartões remotos no cache do GitHub, se necessário, e recarregue seu perfil.

## O que foi corrigido

- Os arquivos `profile/stats.svg` e `profile/top-langs.svg` do README anterior retornavam **404**. Agora os dois cartões apontam para a API pública de `github-readme-stats`. Esse serviço externo pode ter limites de requisições ou indisponibilidades temporárias.
- A cobrinha apontava para arquivos ainda ausentes na branch `output`. O workflow gerará os arquivos; **até a primeira execução bem-sucedida, a cobrinha ainda não aparece**.
- O link de LinkedIn e o link de portfólio, antes genéricos, foram atualizados. O endereço de e-mail existente foi preservado.
- Os quatro cards de projetos continuam. Dois cards usam projetos conhecidos, e dois estão **claramente identificados como futuros**, sem fingir que já foram publicados.

## Observações

- O GitHub não deixa personalizar diretamente a interface nativa da barra lateral: este pacote melhora o conteúdo do `README.md`, que aparece na seção Overview.
- Os troféus, streak e gráfico de atividade dependem de serviços de terceiros e podem falhar temporariamente.
- Caso o repositório use outra branch padrão, ajuste os links que terminam em `/main/` e o disparo `push` do workflow.
